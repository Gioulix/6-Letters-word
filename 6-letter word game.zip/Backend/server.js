const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

//initalizing express app
const app = express();
app.use(cors());

//create API connection to MySQL database
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "mysqldb",
});

//error handling for MySQL connection
db.connect((err) => {
  if (err) {
    console.error("Error connecting to database:", err);
    return;
  }
  console.log("Connected to MySQL database!");
});

module.exports = db;

app.get("/", (req, res) => {
  res.send("Hello World! from backend");
});

//getting data from MySQL database
app.get("/six_leters", (req, res) => {
  db.query(
    "SELECT word FROM six_leters ORDER BY RAND() LIMIT 1",
    (err, results) => {
      if (err) throw err;
      res.json(results[0]);
    }
  );
});

//listening to the port of the server
app.listen(3010, () => {
  console.log(`Server is running on http://localhost:${3010}`);
});
