import { useEffect, useState } from "react";
import "./App.css";
import Word from "./Word.jsx";

function App() {
  return (
    <>
      <Word />
    </>
  );
}

export default App;
